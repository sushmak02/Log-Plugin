<?php
/**
 *
 Plugin Name: Log Customizer Plugin
 Plugin URI:  https://developer.wordpress.org/plugins/the-basics/
 Description: First Wordpress Plugin
 Version:     1.0.2
 Author:      Sushma Kure
 Author URI:  https://codepen.io/sushmak02
 Text Domain: log-textdomain
 Domain Path: /languages
 License:     GPL2
 */

add_action( 'admin_menu' , 'register_log_options' );

//create options page

function register_log_options() {
    
    //add_options_page( $page_title, $menu_title, $capability, $menu_slug, $function );
    add_options_page( 'Page Title', 'Log Menu', 'manage_options', __FILE__, 'log_options_page' );
    add_action( 'admin_init' , 'register_log_settings' );

}


//register settings

function register_log_settings() {

    register_setting( 'log-options-group' , 'log_option_name' );

}


//Define Shortcode

function log_shortcode() {

    $log_name = esc_attr( get_option( 'log_option_name' ) );
    $log_date = date( 'F jS, Y' );
    _e('Hello $log_name Today is $log_date','log-textdomain');

}

add_shortcode( 'log-data' , 'log_shortcode' );


//Contents of option page.

function log_options_page() {   
?>

 <div>
	  <h2>This is my Plugin</h2>
	  <form method="post" action="options.php">
		<?php settings_fields( 'log-options-group' ); ?>

			<?php do_settings_sections( 'log-options-group' ); ?>
			 
			<table>
				<tr>
					<th><label for="log_option_name"> Enter Name : </label></th>
					<td><input type="text" id="log_option_name" name="log_option_name" value="<?php
					echo esc_attr( get_option( 'log_option_name' ) ); ?>" /></td>
				</tr>
			</table>

		<?php  submit_button();	?>
		<?php _e('Use this shortcode in your page : [ log-data ]', 'log-textdomain' ); ?>
	  </form>
 </div>

<?php
}


?>